<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "estacio";

//criar conexao
$conn = mysqli_connect ($servidor, $usuario, $senha, $dbname);